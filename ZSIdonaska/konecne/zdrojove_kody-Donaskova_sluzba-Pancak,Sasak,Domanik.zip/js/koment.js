﻿$(document).ready(function ()
{
	$(".kosikadd").click(function()
	{
	$(this).hide();});
});